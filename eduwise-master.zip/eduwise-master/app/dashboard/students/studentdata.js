export const studentdata = [
    {
        id: 11,
        name: {
            first: 'Sahil',
            last: 'Kumar'
        },
        attendance: 75,
        marks: 80
    },
    {
        id: 12,
        name: {
            first: 'Sajal',
            last: 'Nanda'
        },
        attendance: 85,
        marks: 92
    },
    {
        id: 13,
        name: {
            first: 'Pranay',
            last: 'Kaushik'
        },
        attendance: 70,
        marks: 78
    },
    {
        id: 14,
        name: {
            first: 'SM',
            last: 'Sharan'
        },
        attendance: 92,
        marks: 88
    },
    {
        id: 15,
        name: {
            first: 'Harshit',
            last: 'Chadha'
        },
        attendance: 88,
        marks: 75
    }
    

];