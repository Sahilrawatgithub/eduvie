export const teacherdata = [
    {
        Tid: 1,
        name: {
            first: 'Pranay',
            last: 'Kaushik'
        },
        subject: 'FEE',
        email: 'pranay1039@gmail'
    },
    {
        Tid: 5,
        name: {
            first: 'Elena',
            last: 'Gomez'
        },
        subject: 'Math',
        email: 'elena.math@gmail'
    },
    {
        Tid: 6,
        name: {
            first: 'Robert',
            last: 'Johnson'
        },
        subject: 'Science',
        email: 'robert.science@gmail'
    },
    {
        Tid: 7,
        name: {
            first: 'Sophia',
            last: 'Anderson'
        },
        subject: 'History',
        email: 'sophia.history@gmail'
    },
    {
        Tid: 8,
        name: {
            first: 'William',
            last: 'Taylor'
        },
        subject: 'English',
        email: 'william.english@gmail'
    },
    {
        Tid: 9,
        name: {
            first: 'Olivia',
            last: 'Martin'
        },
        subject: 'Physics',
        email: 'olivia.physics@gmail'
    }
    
]